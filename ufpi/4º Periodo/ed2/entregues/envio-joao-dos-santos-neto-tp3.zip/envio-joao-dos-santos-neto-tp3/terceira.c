#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>
#include <stdbool.h>

#define V 6 // Número de vértices no grafo

typedef struct {
    int vertex;
    double probability; // A probabilidade associada à aresta
} Edge;

typedef struct {
    Edge edges[V]; // Lista de arestas
    int numEdges;
} Graph[V];

double logMaxProb(double prob) {
    if (prob == 0.0) return -INFINITY;
    return -log(prob);
}

int minDistance(double dist[], bool visited[]) {
    double min = INFINITY;
    int minIndex = -1;

    for (int i = 0; i < V; i++) {
        if (!visited[i] && dist[i] < min) {
            min = dist[i];
            minIndex = i;
        }
    }
    return minIndex;
}

void mostReliablePath(Graph graph, int start, int end) {
    double dist[V];
    bool visited[V];
    int predecessors[V];

    for (int i = 0; i < V; i++) {
        dist[i] = INFINITY;
        visited[i] = false;
        predecessors[i] = -1;
    }
    dist[start] = 0.0;

    for (int count = 0; count < V - 1; count++) {
        int u = minDistance(dist, visited);
        visited[u] = true;

        for (int i = 0; i < graph[u].numEdges; i++) {
            int v = graph[u].edges[i].vertex;
            double probability = graph[u].edges[i].probability;
            double negLogProb = logMaxProb(probability);
            if(u != -1)
            {
                if (!visited[v] && dist[u] != INFINITY && dist[u] + negLogProb < dist[v]) {
                    dist[v] = dist[u] + negLogProb;
                    predecessors[v] = u;
                }
            }
        }
    }

    printf("Caminho mais confiável de %d até %d com probabilidade %.4lf\n", start, end, exp(-dist[end]));

    // Imprimir o caminho percorrido
    printf("Caminho percorrido: %d", end);
    int current = end;
    while (predecessors[current] != -1) {
        printf(" <- %d", predecessors[current]);
        current = predecessors[current];
    }
    printf("\n");
}

int main() {
    Graph graph;

    // Preenchendo o grafo com as arestas e probabilidades
    graph[0].edges[0].vertex = 1;
    graph[0].edges[0].probability = 0.8;
    graph[0].edges[1].vertex = 2;
    graph[0].edges[1].probability = 0.7;
    graph[0].numEdges = 2;

    graph[1].edges[0].vertex = 2;
    graph[1].edges[0].probability = 0.9;
    graph[1].edges[1].vertex = 4;
    graph[1].edges[1].probability = 0.5;
    graph[1].numEdges = 2;

    graph[2].edges[0].vertex = 3;
    graph[2].edges[0].probability = 0.3;
    graph[2].numEdges = 1;

    graph[3].edges[0].vertex = 4;
    graph[3].edges[0].probability = 0.6;
    graph[3].edges[1].vertex = 5;
    graph[3].edges[1].probability = 0.95;
    graph[3].numEdges = 2;

    graph[4].numEdges = 0;

    graph[5].edges[0].vertex = 4;
    graph[5].edges[0].probability = 0.67;
    graph[5].numEdges = 1;

    int start, end;
    printf("Digite o vértice de origem: ");
    scanf("%d", &start);

    printf("Digite o vértice de destino: ");
    scanf("%d", &end);

    mostReliablePath(graph, start, end);

    return 0;
}


