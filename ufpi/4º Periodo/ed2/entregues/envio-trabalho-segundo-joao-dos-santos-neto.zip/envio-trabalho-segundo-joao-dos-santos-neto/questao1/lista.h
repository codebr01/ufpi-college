typedef struct lista Lista;

Lista* iniciaLista();
Lista* insereLista(Lista *lista, int linha);

void mostrarLinhas(Lista *lista);