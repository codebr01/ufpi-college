datastructspawner
=================

### Esse pacote contém o uso de algumas estruturas de dados: Lista Encadeada, Árvore Bínaria de Busca e Árvore AVL.

## Instalação:

`pip install datastructspawner`

## Uso:

```
linked-list = LinkedList()
datas = {"name" = "Name-User"}
key = 1
node = NodeLinkedList(key,datas)
linkes-list.add_node(node)
```