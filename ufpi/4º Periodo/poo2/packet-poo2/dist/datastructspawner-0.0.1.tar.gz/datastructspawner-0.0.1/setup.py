from setuptools import setup

# with open('README.md', 'r') as arq:
#     readme = arq.read()

setup(name='datastructspawner',
    version='0.0.1',
    license='MIT License',
    author='Joao Neto e Lindaiely Rodrigues',
    author_email='joaonetoprivado2001@ufpi.edu.br',
    keywords='estrutura de dados',
    description=u'Gerador de estruturas de dados',
    packages=['datastructspawner'],)