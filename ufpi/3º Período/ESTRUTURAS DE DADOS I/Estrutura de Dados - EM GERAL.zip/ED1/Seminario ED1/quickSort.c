#include <stdio.h>
#include <stdlib.h>

void troca(int *vetor, int i, int j) {
    int aux = vetor[i];
    vetor[i] = vetor[j];
    vetor[j] = aux;
}

int particiona(int *vetor, int inicio, int fim) {
    int pivo = vetor[fim];
    int i = inicio - 1;
    int j;
    for (j = inicio; j < fim; j++) {
        if (vetor[j] <= pivo) {
            i++;
            troca(vetor, i, j);
        }
    }
    troca(vetor, i + 1, fim);
    return i + 1;
}

void quickSort(int *vetor, int inicio, int fim) {
    if (inicio < fim) {
        int pivo = particiona(vetor, inicio, fim);
        quickSort(vetor, inicio, pivo - 1);
        quickSort(vetor, pivo + 1, fim);
    }
}

void imprimeVetor(int *vetor, int tamanho) {
    int i;
    for (i = 0; i < tamanho; i++) {
        printf("%d ", vetor[i]);
    }
}

void main() {
    int vetor[10] = { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };
    quickSort(vetor, 0, 9);
    imprimeVetor(vetor, 10);
}