#include <stdio.h>
#include <stdlib.h>
#include "fila.h"

int main(){

    Fila *fila;

    int op = 9;

    while(op > 0){
        printf("\n[ 1 ] - Criar Fila\n[ 2 ] - Inserir na Fila\n[ 3 ] - Retirar da Fila\n[ 4 ] - Mostrar Inicio\n[ 5 ] - Mostrar Final\n[ 6 ] - Mostrar toda a Fila\n[ 0 ] - Sair(Liberar Fila)\nDigite a opcao: ");
        scanf("%i", &op);
        setbuf(stdin,NULL);
        if(op == 1){
            fila = fila_cria();
        }else{
            if(op == 2){
                fila_insere(fila);
            }else{
                if(op == 3){
                    fila_retira(fila);
                }else{
                    if(op == 4){
                        mostrar_inicio(fila);
                    }else{
                        if(op == 5){
                            mostrar_fim(fila);
                        }else{
                            if(op == 6){
                                mostrar_todos_elementos_fila(fila);
                            }else{
                                if(op <= 0){
                                    fila_retira(fila);
                                }
                            }
                        }
                    }
                }
            }
        }
    }



    return 0;
}