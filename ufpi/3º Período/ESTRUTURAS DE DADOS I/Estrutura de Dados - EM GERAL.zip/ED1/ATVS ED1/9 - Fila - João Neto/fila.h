typedef struct fila Fila;//
typedef struct conta Conta;//

Fila* fila_cria (void);//
void fila_insere (Fila *f);//
void fila_retira (Fila *f);//float fila_retira (Fila *f); <- função original[Professor modifiquei por não entendi o retorno do tipo float]
int fila_vazia (Fila *f);//
void fila_libera (Fila *f);//
void mostrar_inicio(Fila *f);//
void mostrar_fim(Fila *f);//
void mostrar_todos_elementos_fila(Fila *f);//

