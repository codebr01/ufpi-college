#include <stdio.h>
#include <stdlib.h>
#include "fila.h"

struct conta{
    char nome[100];
    int numero;
    Conta *prox;
};

struct fila{
    Conta *beggin;
    Conta *end;
};

Fila *fila_cria (void){
    Fila *f = (Fila *)malloc(sizeof(Fila));

    f->beggin = NULL;
    f->end = NULL;

    return f;
}

void fila_insere(Fila *f){
    
    Conta *new = (Conta *)malloc(sizeof(Conta));

    printf("Informe o nome: ");
    scanf("%s", new->nome);
    printf("Informe o numero: ");
    scanf("%i", &new->numero);
    new->prox = NULL;

    if(fila_vazia(f) == 1){
        f->beggin = new;
        f->end = new;
    }
    f->end->prox = new;
    f->end = new;

}

void fila_retira (Fila *f){
    Fila *aux = f;
    f->beggin = f->beggin->prox;
    //free(aux->beggin);
}

int fila_vazia (Fila *f){
    if(f->beggin == NULL){
        return 1;
    }
    return 0;
}

void fila_libera (Fila *f){
    printf("\nLiberando Fila...\n");
    Conta *aux;
    aux = f->beggin->prox;
    while(aux != NULL){
        f->beggin = f->beggin->prox;
        free(aux);
        aux = f->beggin;
    }
}

void mostrar_inicio(Fila *f){
    
    if(fila_vazia(f) == 0){
        printf("\nNome: %s\nNumero: %i\n", f->beggin->nome,f->beggin->numero);
    }else{
        printf("\nLista Vazia!\n");
    }
}

void mostrar_fim(Fila *f){
    
    if(fila_vazia(f) == 0){
        printf("\nNome: %s\nNumero: %i\n", f->end->nome,f->end->numero);
    }else{
        printf("\nLista Vazia!\n");
    }
}

void mostrar_todos_elementos_fila(Fila *f){
    Conta *aux;

    if(fila_vazia(f) == 0){
        aux = f->beggin;
        while(aux != NULL){
            printf("\nNome: %s\nNumero: %i\n", aux->nome,aux->numero);
            aux = aux->prox;
        }
    }else{
        printf("\nLista Vazia!\n");
    }
}