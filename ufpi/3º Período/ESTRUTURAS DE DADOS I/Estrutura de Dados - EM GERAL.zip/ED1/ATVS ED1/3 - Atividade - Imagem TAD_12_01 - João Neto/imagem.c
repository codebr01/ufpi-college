#include <stdio.h>
#include <stdlib.h>
#include "imagem.h"

struct pixel{
	int valor, x, y;
};

struct imagem{
	Pixel *pixels;
	int largura, altura;
};

void alterarPixel(Imagem *img, int posicao, int valor){
	img->pixels[posicao].valor = valor;
}

int obterPixel(Imagem *img,int posicao){
	return img->pixels[posicao].valor;
}

Imagem *criarImagem(int largura, int altura){
	
	Imagem *img = (Imagem *)malloc(sizeof(Imagem));
	img->altura = altura;
	img->largura = largura;
	img->pixels = (Pixel *)malloc(altura*largura*sizeof(Pixel));

	return img;
}

void preencherImagem(Imagem *img){
	for(int i = 0; i < img->largura; i++){
		for(int j = 0; j < img->altura; j++){
			setPixelValue(img,i,j,0);
		}
	}
}

void setPixelValue(Imagem *img, int y, int x, int valor){
	int k;
	k = (y * img->largura) + x;
	img->pixels[k].valor = valor;
	img->pixels[k].x = x;
	img->pixels[k].y = y;
}

void imprimirImagem(Imagem *img){
	int k;
	for(int i = 0; i < img->largura; i++){
		for(int j = 0; j < img->altura; j++){
			k = (i * img->largura) + j;
			printf("%i   ", img->pixels[k].valor);
		}
		printf("\n");
	}
}

int getPixelValue(Imagem *img, int y, int x){
	return img->pixels[(y*img->largura) + x].valor;
}

void liberarImagem(Imagem *img){
	free(img->pixels);
	free(img);
}