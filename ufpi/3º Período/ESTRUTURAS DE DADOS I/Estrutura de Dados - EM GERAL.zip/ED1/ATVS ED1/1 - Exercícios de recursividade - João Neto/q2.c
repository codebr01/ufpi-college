#include <stdio.h>
#include <stdlib.h>

void mostraNumero(int num){
    if(num < 0) return 0;
    printf("%i ", num);
    return mostraNumero(num - 1);
}
int main(){

    int num;
    scanf("%i", &num);
    mostraNumero(num);

    return 0;
}