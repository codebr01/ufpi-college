#include <stdio.h>
#include <stdlib.h>

float exponencial(float b, int p){

    if(p == 0){
        return 1;
    }
    return b * exponencial(b,p - 1);
}
int main(){

    float b;
    int p;
    scanf("%f %i", &b, &p);
    printf("Resultado: %f\n", exponencial(b,p));

    return 0;
}