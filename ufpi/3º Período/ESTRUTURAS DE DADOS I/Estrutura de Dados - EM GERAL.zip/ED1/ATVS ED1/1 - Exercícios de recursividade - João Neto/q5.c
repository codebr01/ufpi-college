#include <stdio.h>
#include <stdlib.h>

float calculaExponencial(float a, int b){
    if(b == 0) return 1;
    return a * calculaExponencial(a, b - 1);
}

float calculaJuros(int c, int n, float i){
    return c * calculaExponencial(1 - i, n);
}
int main(){

    int n;
    float c, i;
    scanf("%f %i %f", &c, &n, &i);
    printf("Resultado: %.1f\n", calculaJuros(c,n,i));

    return 0;
}