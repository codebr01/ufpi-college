#include <stdio.h>
#include <stdlib.h>

int mostraNumeroSoma(int num){
    if(num < 0) return 0;
    return num + mostraNumeroSoma(num - 1);
}
int main(){

    int num;
    scanf("%i", &num);
    printf("Resultado: %i\n", mostraNumeroSoma(num));

    return 0;
}