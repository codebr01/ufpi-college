#include <stdio.h>
#include <stdlib.h>

int mostraNumeroSomaAB(int a, int b){
    if(a == b) return 0;
    return a + mostraNumeroSomaAB(a + 1,b);
}
int main(){

    int a,b;
    scanf("%i %i", &a, &b);
    printf("Resultado: %i\n", mostraNumeroSomaAB(a + 1,b));

    return 0;
}