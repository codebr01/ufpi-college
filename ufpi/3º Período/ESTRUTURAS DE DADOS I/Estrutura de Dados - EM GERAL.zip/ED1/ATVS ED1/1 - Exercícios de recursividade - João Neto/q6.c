#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int procuraVetor(int *v, int num, int tam){
    if(num == v[tam]){
        return 0;
    }else{
        if(tam < 0){
            return 1;
        }
    }
    return procuraVetor(v,num,tam - 1);
}

int main(){
    srand(time(NULL));
    int *v, num,tam,lim;

    scanf("%i %i %i", &tam, &num, &lim);

    v = (int*) calloc(tam,sizeof(int));
    for(int i = 0; i < tam; i++){
        v[i] = rand() % lim;
        //printf("%i ", v[i]);
    }printf("\n");
    
    if(procuraVetor(v,num,tam) == 0){
        printf("Achei o %i na no vetor!\n",num);
    }else{
        printf("Não achei o numer %i no vetor!\n", num);
    }

    free(v);

    return 0;
}