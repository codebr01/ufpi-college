#include <stdio.h>
#include <stdlib.h>
#include "cabeçalho.h"

struct conta{
    float saldo;
    int num_conta;
    char nome[100];
};

int menu(){
    int op;
    printf("DIGITE [ -1 ] P/ EXIT\nDIGITE [ 1 ] P/ create_list_static\nDIGITE [ 2 ] P/ insert_element\nDIGITE [ 3 ] P/ remove_element\nDIGITE [ 4 ] P/ show_element\nDIGITE [ 5 ] P/ show_all_elements\nDIGITE [ 6 ] P/ VER SALDO DA CONTA\nDIGITE [ 7 ] P/ LIMPAR MEMORIA\nOPCAO: ");
    scanf("%i", &op);
    return op;
}

Conta *create_list_static(int tam){
    Conta *list = (Conta *)malloc(tam*sizeof(Conta));
    for(int i = 0; i < tam; i++){
        list[i].num_conta = -1;//posição livre
    }
    return list;
}

void *insert_element(Conta *list, int posix, int tamanho){
    printf("Digite o nome: ");
    scanf("%[^\n]s",list[posix].nome);
    printf("Digite o numero da conta: ");
    scanf("%i", &list[posix].num_conta);
    printf("Digite o saldo da conta: ");
    scanf("%f", &list[posix].saldo);
}

void remove_element(Conta *list, int tam){
    int num_conta_del,posix;
    printf("Informe o numero da conta que deseja remover: ");
    scanf("%i", &num_conta_del);
    setbuf(stdin,NULL);
    posix = seach_element(list,tam,num_conta_del);
    if(posix != -1){
        list[posix].num_conta = -1;
        list[posix].saldo = 0;
        printf("\n## CONTA REMOVIDA ##\n");
    }else{
        printf("OPS :(\nVOCE INFORMOU UMA CONTA QUE NAO EXISTE\n");
    }
    
}

int seach_element(Conta *list, int tam, int num_conta){
    for(int i = 0; i < tam; i++){
        if(num_conta == list[i].num_conta){
            return i;
        }
    }
    return -1;
}

void show_element(Conta *list, int posix){
    printf("Nome: %s\nNumero da conta: %i\nSaldo atual: %.2f\n=======\n", list[posix].nome, list[posix].num_conta, list[posix].saldo);
}

void show_all_elements(Conta *list, int tam){
    printf("=======\n");
    for(int i = 0; i < tam ; i++){
        show_element(list,i);
    }
}

void show_saldo(Conta *list, int num_account, int tam){
    int posix = seach_element(list,tam,num_account);
    printf("\nSALDO DA CONTA %i: %.2f\n", num_account, list[posix].saldo);
}

void free_memory(Conta *lista){
    printf("\nMEMORIA LIMPA\n");
    free(lista);
}

int space_free(Conta *list, int tam, int posix){
    if(list[posix].num_conta == -1){
        return 0;
    }else{
        return 1;
    }
}