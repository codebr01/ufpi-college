typedef struct conta Conta;

//CRIA UMA LISTA COM TAMANHO TAM E COLOCA -1 EM TODOS NUM_CONTA
Conta *create_list_static(int tam);
//INSERE UM VALOR EM POSIX
void *insert_element(Conta *list, int posix, int tamanho);
//REMOVE UM ELEMENTO DA LISTA
void remove_element(Conta *list, int tam);//remover pelo num_conta
//FUNÇÃO DE PROCURAR UM ELEMNTO NA LISTA | RETURN POSIX TRUE OR -1 FALSE
int seach_element(Conta *list, int tam, int num_conta);
//FUNÇÃO DE MOSTRAR UM ELEMENTO NO VETOR
void show_element(Conta *list, int posix);
//FUNÇÃO DE MOSTRAR TODOS OS ELEMENTOS(REUTILIZA A FUNÇÃO show_element)
void show_all_elements(Conta *list, int tam);
//MOSTRAR SALDO DE UMA CONTA
void show_saldo(Conta *list, int num_account, int tam);
//LIMPA A MEMORIA DA LISTA
void free_memory(Conta *lista);
//MENU
int menu();
//VERIFICA SE A POSIÇÃO É LIVRE
int space_free(Conta *list, int tam, int posix);