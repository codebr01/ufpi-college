#include <stdio.h>
#include <stdlib.h>
#include "cabeçalho.h"

void main(){
    Conta *list;
    int op,tam,posix,num_conta;
    for(;;){
        op = menu();
        if(op == -1){
            break;
        }else{
            if(op == 1){
                printf("Informe o tamanho do vetor: ");
                scanf("%i", &tam);
                setbuf(stdin,NULL);
                list = create_list_static(tam);
            }else{
                if(op == 2){
                    printf("Informe a posição que deseja inserir: ");
                    scanf("%i", &posix);
                    setbuf(stdin,NULL);
                    if(space_free(list,tam,posix) == 0){
                        insert_element(list,posix,tam);
                    }else{
                        printf("\n[ERROR]POSIÇÃO %i JA OCUPADA!\n",posix);
                    }
                }else{
                    if(op == 3){
                        remove_element(list,tam);
                    }else{
                        if(op == 4){
                            printf("Informe o numero da posicao: ");
                            scanf("%i", &posix);
                            setbuf(stdin,NULL);
                            show_element(list,posix);
                        }else{
                            if(op == 5){
                                show_all_elements(list,tam);
                            }else{
                                if(op == 6){
                                    printf("Informe o numero da conta: ");
                                    scanf("%i", &num_conta);
                                    setbuf(stdin,NULL);
                                    show_saldo(list,num_conta,tam);
                                }else{
                                    if(op == 7){
                                        free_memory(list);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
}