typedef struct conta Conta;

Conta *criar();
Conta *inserir(Conta *lista);
Conta *inserirFim(Conta *lista);
Conta *inserirOrdenado(Conta *lista);
Conta *remover(Conta *lista, int value);
Conta *buscar(Conta *lista, int valor);
Conta *alterar(Conta *lista, int oldValue, int newValue);
int listaVazia(Conta *lista);
void mostrar(Conta *lista);
void liberarLista(Conta *lista);