#include <stdio.h>
#include <stdlib.h>
#include "listaDinamicaDupla.h"

struct conta{
    int numConta;
    float saldo;
    char titular[100];
    Conta *proximo;
    Conta *anterior;
};


Conta *criar(){
    return NULL;
}

Conta *inserir(Conta *lista){
    Conta *new = (Conta *)malloc(sizeof(Conta)), *aux = lista;

    new->numConta = rand() % 100;
    printf("Insira o saldo: "); 
    scanf("%f", &new->saldo);
    setbuf(stdin,NULL);
    printf("Insira o nome do titular: "); 
    scanf("%s", new->titular);
    setbuf(stdin,NULL);
    new->anterior = NULL;

    if(listaVazia(lista)){
        new->proximo = NULL;
        return new;
    }

    aux->anterior = new;
    new->proximo = aux;

    return new;
}

Conta *inserirFim(Conta *lista){
    Conta *new = (Conta *) malloc(sizeof(Conta)), *aux = lista;

    new->numConta = rand() % 100;
    printf("Insira o saldo: "); 
    scanf("%f", &new->saldo);
    setbuf(stdin,NULL);
    printf("Insira o nome do titular: "); 
    scanf("%s", new->titular);
    setbuf(stdin,NULL);
    new->proximo = NULL;

    if(listaVazia(lista)){
        new->anterior = NULL;
        return new;
    }

    while(aux->proximo != NULL){
        aux = aux->proximo;
    }

    aux->proximo = new;
    return lista;
}

Conta *inserirOrdenado(Conta *lista){
    Conta *new = (Conta *) malloc(sizeof(Conta)), *aux = lista;

    new->numConta = rand() % 100;
    printf("Insira o saldo: "); 
    scanf("%f", &new->saldo);
    setbuf(stdin,NULL);
    printf("Insira o nome do titular: "); 
    scanf("%s", new->titular);
    setbuf(stdin,NULL);

    if(listaVazia(lista)){
        new->proximo = NULL;
        new->anterior = NULL;
        return new;
    }

    if(aux->numConta > new->numConta){
        aux->anterior = new;
        new->proximo = aux;
        new->anterior = NULL;
        return new;
    }

    while(aux->proximo != NULL && aux->proximo->numConta < new->numConta){
        aux = aux->proximo;
    }

    if(aux->proximo == NULL){
        new->proximo = NULL;
        new->anterior = aux;
        aux->proximo = new;
        return lista;
    }

    new->proximo = aux->proximo;
    aux->proximo = new;
    new->anterior = aux;
    new->proximo->anterior = new;

    return lista;
}

Conta *remover(Conta *lista, int value){
    Conta *aux = lista, *aux2;

    if(listaVazia(lista)){
        printf("Lista Vazia!\n");
        return lista;
    }

    if(aux->numConta == value){

        if(aux->proximo == NULL){
            return NULL;
        }

        aux->proximo->anterior = NULL;
        lista = aux->proximo;
        free(aux);
        return lista;
    }

    while(aux->proximo != NULL && aux->proximo->numConta != value){
        aux = aux->proximo;
    }

    if(aux->proximo == NULL){
        printf("Conta nao existe!\n");
        return lista;
    }

    aux2 = aux->proximo;
    aux->proximo = aux->proximo->proximo;
    free(aux2);

    if(aux->proximo == NULL){
        return lista;
    }

    aux->proximo->anterior = aux;

    return lista;
}

Conta *buscar(Conta *lista, int valor){
    Conta *aux = lista;

    while(aux != NULL && aux->numConta != valor){
        aux = aux->proximo;
    }

    return aux == NULL? NULL : aux;
}

Conta *alterar(Conta *lista, int oldValue, int newValue){
    Conta *item = buscar(lista, oldValue);

    if(item){
        item->numConta = newValue;
        printf("Insira o saldo: "); 
        scanf("%f", &item->saldo);
        setbuf(stdin,NULL);
        printf("Insira o nome do titular: "); 
        scanf("%s", item->titular);
        setbuf(stdin,NULL);
    }

    return lista;
}

int listaVazia(Conta *lista){
    return lista == NULL ? 1 : 0;
}

void mostrar(Conta *lista){
    Conta *aux = lista;

    if(aux == NULL){
        printf("Lista vazia!\n");
        return;
    }
	printf("- - - - CONTA - - - -\n");
    do{
        printf("Numero: %i\nSaldo: %.2f\nTitular: %s\n", aux->numConta,aux->saldo,aux->titular);
        printf("- - - - - - - - - - - -\n");
        aux = aux->proximo;
    }while(aux != NULL);
    
}

void liberarLista(Conta *lista){
    Conta *aux = lista;
    if(listaVazia(lista)){
        printf("Lista Vazia!\n");
        return;
    }

    do{
        aux = lista->proximo;
        free(lista);
        lista = aux;
    } while(aux != NULL);

    printf("Lista limpa...\n");
}
