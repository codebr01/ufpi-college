#include <stdio.h>
#include <stdlib.h>

#include "listaDinamicaDupla.h"


struct conta{
	float saldo;
	char titular[100];
	int num_conta;
	struct conta *prox, *ant;
};

Conta *criarLista(){
	return NULL;
}

Conta *inserirInicio(Conta *lista){
	Conta *new = (Conta*) calloc(sizeof(Conta),1);
	Conta *aux;
	aux = lista;
	new->num_conta = rand() % 100 + 10;
	printf("Nome - ");
	scanf("%s", new->titular);
	printf("Saldo - ");
	scanf("%f", &new->saldo);
	new->ant = NULL;
	new->prox = NULL;
	if(lista == NULL){
		return new;
	}
	aux->ant = new;
	new->prox = aux;
	return new;	
}

Conta *inserirFim(Conta *lista){
	Conta *new = (Conta*) calloc(sizeof(Conta),1);
	Conta *aux;
	aux = lista;
	new->num_conta = rand() % 100 + 10;
	printf("Nome - ");
	scanf("%s", new->titular);
	printf("Saldo - ");
	scanf("%f", &new->saldo);
	new->ant = NULL;
	new->prox = NULL;
	if(lista == NULL){
		return new;
	}
}

Conta *remover(Conta *lista, int valor){
	Conta *item;
	Conta *aux;
	aux = lista;
	if(aux != NULL){
		item = buscar(aux,valor);
		if(item != NULL){
			if(item->ant == NULL){
				aux = item->prox;
				aux->ant = NULL;
				free(item);
				return aux;
			}else{
				if(item->prox == NULL){
					item->ant->prox = NULL;
					free(item);
					return lista;
				}else{
					item->ant->prox = item->prox;
					free(item);
					return lista;
				}
			}
		}else{
			printf("Valor nao encontrado!\n");
			return NULL;
		}
	}else{
		printf("Lista vazia!\n");
		return lista;
	}
}

Conta *alterar(Conta *lista, int oldValue, int newValue){
	Conta *item;
	Conta *aux;
	aux = lista;
	item = buscar(aux,oldValue);
	if(item != NULL){
		item->saldo = newValue;
	}else{
		printf("oldValue nao encontrado!\n");
	}
	return lista;
}

Conta *buscar(Conta *lista, int valor){
	Conta *p;
	for(p = lista; p != NULL; p = p->prox){
		if(p->saldo == valor){
			return p;
		}
	}
	return NULL;
}

void mostrarLista(Conta *lista){
	Conta *p;
	printf("- - - - - - - - \n");
	for(p = lista; p != NULL; p = p->prox){
		printf("Nome: %s\nNum Conta: %i\nSaldo: %.2f\n", p->titular,p->num_conta, p->saldo);
		printf("- - - - - - - - \n");
	}
}

int listaVazia(Conta *lista){
	if(lista == NULL){
		return 1;
	}else{
		return 0;
	}
}

void liberarLista(Conta *lista){
	Conta *aux;
	aux = lista;
	if(aux != NULL){
		liberarLista(aux->prox);	
		printf("Limpando %i...\n",aux->num_conta);
		free(aux);
	}
	lista = NULL;
}