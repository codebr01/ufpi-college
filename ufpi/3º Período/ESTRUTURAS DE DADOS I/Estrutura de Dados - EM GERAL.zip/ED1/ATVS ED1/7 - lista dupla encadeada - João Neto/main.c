#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "listaDinamicaDupla.h"

int main(){
    Conta *lista;
    int option, value, new;

    srand(time(NULL));

    lista = criar();

    while(1){
        printf("[ 1 ] - Inserir no inicio.\n[ 2 ] - Inserir no final.\n[ 3 ] - Inserir Ordenado.\n[ 4 ] - Remover conta.\n[ 5 ] - alterar.\n[ 6 ] - Mostrar lista.\n[ 7 ] - Sair.\nInsira uma opcao: ");
        scanf("%i", &option);
        setbuf(stdin,NULL);

        switch(option){
            case 1:
                lista = inserir(lista);
                break;
            
            case 2:
                lista = inserirFim(lista);
                break;
            
            case 3:
                lista = inserirOrdenado(lista);
                break;

            case 4:
                printf("\nInsira o numero da conta: "); 
                scanf("%i", &value);
                setbuf(stdin,NULL);
                lista = remover(lista, value);
                break;

            case 5:
                printf("\nInsira o numero da conta: "); 
                scanf("%i", &value);
                setbuf(stdin,NULL);
                printf("\nInsira o novo numero: "); 
                scanf("%i", &new);
                setbuf(stdin,NULL);
                alterar(lista, value, new);
                break;

            case 6:
                mostrar(lista);
                break;

            case 7:
                liberarLista(lista);
                return 0;
            
            default:
                printf("\nInsira uma opcao valida!\n");
        }

    }

    return 0;
}
