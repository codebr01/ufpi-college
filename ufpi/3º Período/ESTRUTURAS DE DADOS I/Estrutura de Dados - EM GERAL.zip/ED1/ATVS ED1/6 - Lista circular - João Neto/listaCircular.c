#include <stdio.h>
#include <stdlib.h>

#include "listaCircular.h"


struct conta{
	float saldo;
	char titular[100];
	int num_conta;
	struct conta *prox;
};

Conta *criarLista(){
	return NULL;
}

Conta *inserir(Conta *lista){
	
	Conta *new = (Conta*) malloc(sizeof(Conta)), *aux;
	
	new->num_conta = rand() % 100 + 10;
	printf("Nome - ");
	scanf("%s", new->titular);
	printf("Saldo - ");
	scanf("%f", &new->saldo);
	
	if (!lista)//se a lista for vazia o primeiro e o ultimo sao iguais
	{
		new->prox = new;
	}
	else{
		aux = lista;
		while(aux->prox != lista){
			aux = aux->prox;
		}
		aux->prox = new;
		new->prox = lista;
	}
	return new;
}

Conta *inserirFim(Conta *lista){
	Conta *new, *aux;
	new = (Conta*) malloc(sizeof(Conta));

	new->num_conta = rand() % 100 + 10;
	printf("Nome - ");
	scanf("%s", new->titular);
	printf("Saldo - ");
	scanf("%f", &new->saldo);

	if (!lista)//se a lista for vazia o primeiro e o ultimo sao iguais
	{
		new->prox = new;
		return new;
	}
	else{
		aux = lista;
		while(aux->prox != lista){
			aux = aux->prox;
		}
		aux->prox = new;
		new->prox = lista;
	}
	return lista;

}

Conta *inserirOrdenado(Conta *lista){
	Conta *new;
	new = (Conta*) malloc(sizeof(Conta));

	new->num_conta = rand() % 100 + 10;
	printf("Nome - ");
	scanf("%s", new->titular);
	printf("Saldo - ");
	scanf("%f", &new->saldo);

	if (lista == NULL)//se a lista for vazia o primeiro e o ultimo sao iguais
	{
		new->prox = new;
		return new;
	}else{
		Conta *ant;
		Conta *aux;
		ant = NULL;
		aux = lista;
		if(aux->saldo > new->saldo){
			new->prox = aux;
			while(aux->prox != lista){
				aux = aux->prox;
			}
			aux->prox = new;
			return new;
		}
		while(aux->prox != lista && new->saldo > aux->saldo && new->saldo > aux->prox->saldo){
			aux = aux->prox;
		}
		new->prox = aux->prox;
		aux->prox = new;
		return lista;
	}
}

Conta *alterar(Conta *lista, int oldValue, int newValue){
	Conta *item,*aux;
	aux = lista;
	item = buscar(aux,oldValue);
	if(item != NULL){
		item = buscar(aux,newValue);
		if(item == NULL){
			item->num_conta = newValue;
			return lista;
		}else{
			printf("newValue ja esta cadastrado!\n");
			return NULL;
		}
	}else{
		printf("oldValue nao encontrado!\n");
		return NULL;
	}
}

Conta *remover(Conta *lista, int valor){
	Conta *item,*aux,*ant;
	aux = lista;
	ant = NULL;
	item = buscar(aux,valor);
	if(item != NULL){
		while(aux->prox != lista && aux->num_conta != item->num_conta){
			ant->prox = aux;
			aux = aux->prox;
		}
		if(aux->prox == lista){
			ant->prox = aux->prox;
			free(aux);
			return lista;
		}else{
			if(ant == NULL){
				item->prox = aux->prox;
				free(aux);
				return item;
			}else{
				ant->prox = aux->prox;
				free(aux);
				return lista;
			}
		}
	}else{
		printf("Valor %i nao encontrado!\n", valor);
		return lista;
	}
}

Conta *buscar(Conta *lista, int valor){
	Conta *aux;
	aux = lista;
	while(aux->prox != lista){
		if(aux->num_conta == valor){
			return aux;
		}
		aux = aux->prox;
	}
	return lista;
}

void mostrarLista(Conta *lista){
	Conta *p = lista; 
	if(p != NULL){
		do{
			printf("- - - - - - - - - - - -\n");
			printf("Nome: %s\nConta: %i\nSaldo: %.2f\n",p->titular,p->num_conta,p->saldo);
			printf("- - - - - - - - - - - -\n");
			p = p->prox; /* avança para o próximo elemento da lista*/
		}while(p != lista);
	}
}

void liberarLista(Conta *lista){
	Conta *aux;
	aux = lista;
	if(aux != NULL){
		liberarLista(aux->prox);
		free(aux);
	}
}

int listaVazia(Conta *lista){
	if(lista == NULL){
		return 1;
	}
	return 0;
}