#include <stdio.h>
#include <stdlib.h>

#include "listaCircular.h"

int main(){
	
	Conta *lista;
	lista = criarLista();

	/* lista = inserir(lista);
	lista = inserir(lista);
	lista = inserir(lista);

	lista = inserirFim(lista);
	lista = inserirFim(lista);
	lista = inserirFim(lista); */

	lista = inserirOrdenado(lista);
	lista = inserirOrdenado(lista);
	lista = inserirOrdenado(lista);
	lista = inserirOrdenado(lista);

	mostrarLista(lista);

	lista = remover(lista,50);
	lista = alterar(lista,50,69);

	liberarLista(lista);
	if(lista == NULL){
		printf("Lista vazia!\n");
	}else{
		printf("Func nao executada corretamente!\n");
	}

	return 0;
}