#include <stdio.h>
#include <stdlib.h>
#include "str.h"

char *ler(){

    char *str;
    str = (char *) calloc(255,sizeof(char));
    printf("Digite a string: ");
    scanf("%s", str);    
    setbuf(stdin,NULL);

    return str;
}

int tamanho(char *str){
    int i;
    for(i = 0; str[i] != '\0'; i++);
    return i;
}

char *concatenar(char *str1, char *str2){
    int tam1 = tamanho(str1);
    int tam2 = tamanho(str2);

    str1 = (char *)realloc(str1,tam1+tam2);
    
    for(int i = 0; str2[i] != '\0'; i++,tam1++){
        str1[tam1] = str2[i];
    }
    str1[tam1] = '\0';
    return str1;
}

int comparar(char *str1, char *str2){
    if(tamanho(str1) != tamanho(str2)){
        return 1;
    }else{
        int cont = 0;
        for(int i = 0,j = 0; str1[i] != '\0'; i++,j++){
            if(str1[i] == str2[j]){
                cont++;
            }else{
                return 1;
            }
        }
        if(cont == tamanho(str1)){
            return 0;
        }
    }
}

void liberar(char *str){
    free(str);
}   