//Essa função recebe a leitura do teclado e retorna a primeira posição 
char *ler();
//Essa função retorna o tamanho da string digitada
int tamanho(char *str);
//Essa função retorna duas strings concatenadas
char *concatenar(char *str1, char *str2);
// Essa função retorna 0 para True e 1 para False
int comparar(char *str1, char *str2);
//Libera espaço de memoria alocado
void liberar(char *str);