#include <stdio.h>
#include <stdlib.h>
#include "str.h"

int main(){

    char *str1, *str2;
    str1 = ler();
    str2 = ler();
    if(comparar(str1,str2) == 0){
        printf("\nAs strings são iguais!\n");
    }else{
        printf("\nAs strings não são iguais!\n");
    }
    printf("\nString 1 digitada: %s\nString 2 digitada: %s\n\n", str1, str2);
    printf("Tamanho da string 1: %i\nTamanho da string 2: %i\n\n", tamanho(str1),tamanho(str2));
    printf("Strings contatenadas: %s\n\n", concatenar(str1,str2));
    liberar(str1);
    liberar(str2);

    return 0;
}
