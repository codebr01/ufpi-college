typedef struct product Product;

typedef struct tree Tree;

Tree *createTree();

Product **treeSearch(Product **node, int value);

Product **searchBiggestNodeLeft(Product **node);

void swap(Product **nodeToRemove, Product **node);

void insertProduct(Tree *tree, int value);

void searchProduct(Tree *tree);

void updateProduct(Tree *tree);

void removeProduct(Tree *tree, int value);

void print(Product *node);

void printTree(Tree *tree);
