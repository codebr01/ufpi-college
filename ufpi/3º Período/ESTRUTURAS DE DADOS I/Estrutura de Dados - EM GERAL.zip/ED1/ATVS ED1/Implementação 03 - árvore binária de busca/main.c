#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "estoque.h"

int main()
{
    int vet[4] = {9,8,11,10};
    Tree *tree = createTree();

    for (int i = 0; i < 4; i++){
        insertProduct(tree, vet[i]);
    }

    removeProduct(tree, 10);

    printTree(tree);
    return 0;
}