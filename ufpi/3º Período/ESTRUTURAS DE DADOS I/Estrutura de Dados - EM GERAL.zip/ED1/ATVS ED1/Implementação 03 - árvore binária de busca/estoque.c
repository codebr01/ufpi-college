#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "estoque.h"

struct product {
    int code;
    //int quantity;
    //char name[50];
    //float price;
    Product *right, *left;
};

struct tree {
    Product *root;
};

Tree *createTree() {
    Tree *tree = (Tree *) malloc(sizeof(Tree));
    tree->root = NULL;
    return tree;
}

Product **treeSearch(Product **node, int value) {
    Product **address;

    if ((*node) != NULL) {
        if ((*node)->code > value) {
            address = treeSearch(&(*node)->left, value);

        } else if ((*node)->code < value) {
            address = treeSearch(&(*node)->right, value);

        } else {
            address = node;
        }

    } else {
        address = node;
    }

    return address;
}

Product **searchBiggestNodeLeft(Product **node) {
    if ((*node)->right != NULL) {
        searchBiggestNodeLeft(&(*node)->right);
    } else {
        return node;
    }
}

void swap(Product **nodeToRemove, Product **node) {
    (*node)->left = (*nodeToRemove)->left;
    (*node)->right = (*nodeToRemove)->right;
    free((*nodeToRemove));
    (*nodeToRemove) = (*node);
    (*node) = NULL;
}

void insertProduct(Tree *tree, int value) {
    Product *new = (Product *) malloc(sizeof(Product)), **addressNodeFound;

    new->left = NULL; new->right = NULL;
    //printf("\nInsira a quantidade: "); scanf("%d", &new->quantity);
    //printf("Insira o nome: "); scanf("%s", new->name);
    //printf("Insira o preco: "); scanf("%f", &new->price);
    //new->code = rand() % 100;
    new->code = value;

    addressNodeFound = treeSearch(&tree->root, new->code);

    if ((*addressNodeFound) == NULL) {
        (*addressNodeFound) = new;
        printf("\nProduto cadastrado com sucesso!\n");

    } else {
        printf("\nProduto ja cadastrado!\n");
    }
}

void searchProduct(Tree *tree) {
    Product **productAddress;
    int value;

    printf("\nInsira o ID do produto que deseja procurar: ");
    scanf("%d", &value);

    if (tree->root != NULL) {
        productAddress = treeSearch(&tree->root, value);

        if ((*productAddress) != NULL) {
            print((*productAddress));
        } else {
            printf("\nProduto fora de estoque!\n");
        }

    } else {
        printf("\nEstoque vazio!\n");
    }
}

void updateProduct(Tree *tree) {
    Product **addressProduct;
    int value;

    printf("\nInsira o ID do produto que deseja procurar: ");
    scanf("%d", &value);

    addressProduct = treeSearch(&tree->root, value);

    if (addressProduct != NULL) {
        //printf("\nInsira a quantidade: "); scanf("%d", &new->quantity);
        //printf("Insira o nome: "); scanf("%s", new->name);
        //printf("Insira o preco: "); scanf("%f", &new->price);
    } else {
        printf("\nProduto nao encontrado!\n");
    }
}

void removeProduct(Tree *tree, int value) {
    Product **addressProduct, **addressNodeFound;
    //int value;

    //printf("\nInsira o ID do produto que deseja procurar: ");
    //scanf("%d", &value);

    addressProduct = treeSearch(&tree->root, value);

    if ((*addressProduct)->left != NULL) {
        addressNodeFound = searchBiggestNodeLeft(&(*addressProduct)->left);
        swap(addressProduct, addressNodeFound);
    } else {
        (*addressProduct) = (*addressProduct)->right;
    }
}

void print(Product *node) {
        if (node != NULL) {
            printf("\nID: %d\n", node->code);
            //printf("Quantity: %d\n", node->quantity);
            //printf("Name: %s\n", node->name);
            //printf("Price: %.2f\n", node->price);

            print(node->left);
            print(node->right);
        }
    }

void printTree(Tree *tree) {
    print(tree->root);
}