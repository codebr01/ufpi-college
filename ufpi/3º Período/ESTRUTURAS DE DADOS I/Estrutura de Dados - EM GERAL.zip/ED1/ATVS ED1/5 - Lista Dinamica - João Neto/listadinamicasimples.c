#include <stdio.h>
#include <stdlib.h>

#include "listadinamicasimples.h"

/* 
	PROFESSOR O CODIGO ESTÁ FEITO, PORÉM NÃO FIZ TODOS OS TRATAMENTOS.
*/

struct conta{
	float saldo;
	char titular[100];
	int num_conta;
	struct conta *prox;
};

Conta *criarLista(){
	return NULL;
}

Conta *inserirInicio(Conta *lista){
	Conta *new = (Conta*) malloc(sizeof(Conta));
	new->num_conta = rand() % 100 + 10;
	/* printf("Informe o numero da conta: ");
	scanf("%i", &new->num_conta); */
	printf("Nome: ");
	scanf("%s", new->titular);
	printf("Saldo: ");
	scanf("%f", &new->saldo);
	new->prox = lista;
	return new;
}

Conta *inserirFim(Conta *lista){
	Conta *new = (Conta*) malloc(sizeof(Conta));
	new->num_conta = rand() % 100 + 10;
	/* printf("Informe o numero da conta: ");
	scanf("%i", &new->num_conta); */
	printf("Nome: ");
	scanf("%s", new->titular);
	printf("Saldo: ");
	scanf("%f", &new->saldo);
	new->prox = NULL;
	if(lista == NULL){
		return new;
	}
	Conta *aux = lista;
	while(listaVazia(aux) != 1){
		aux = aux->prox;
	}
	aux->prox = new;
	return lista;
}

Conta *inserirOrdenado(Conta *lista){
	Conta *new;
	new = (Conta*) malloc(sizeof(Conta));
	new->num_conta = rand() % 100 + 10;	
	/* printf("Informe o numero da conta: ");
	scanf("%i", &new->num_conta); */
	printf("Nome: ");
	scanf("%s", new->titular);
	printf("Saldo: ");
	scanf("%f", &new->saldo);
	new->prox = NULL;
	if(lista == NULL){
		return new;
	}
	Conta *aux;
	aux = lista;
	Conta *ant;
	ant = NULL;
	while(aux != NULL && new->num_conta > aux->num_conta){
		ant = aux;
		aux = aux->prox;
	}
	if(ant == NULL){
		new->prox = aux;
		return new;
	}else{
		if(aux == NULL){
			ant->prox = new;
			return lista;
		}else{
			if(aux != NULL){
				ant->prox = new;
				new->prox = aux->prox;
				return lista;
			}	
		}
	}
			
}

Conta *remover(Conta *lista, int valor){
	Conta *item = buscar(lista,valor);
	if(item != NULL){
		Conta *aux = lista;
		while(aux->prox != item){
			aux = aux->prox;
		}
		aux->prox = item->prox;
		free(item);
		return lista;
	}else{
		printf("Valor[ %i ] informado nao esta na lista\n",valor);
		return lista;
	}

}

Conta *buscar(Conta *lista, int valor){
	Conta *aux = lista;
	while(aux != NULL && aux->num_conta != valor){
		aux = aux->prox;
	}
	if(aux != NULL){
		return aux;
	}else{
		return NULL;
	}
}

Conta *alterar(Conta *lista, int oldValue, int newValue){
	Conta *item;
	item = buscar(lista,newValue);
	if(item != NULL){
		printf("Voce informou um newValue[ %i ] ja cadastrado!\n",newValue);
		return lista;
	}else{
		item = buscar(lista,oldValue);
		if(item != NULL){
			item->num_conta = newValue;
			printf("O oldValue[ %i ] foi trocado po -> newValue[ %i ]\n",oldValue,newValue);
			return lista;
		}else{
			printf("Voce informou um oldValue[ %i ] que nao esta cadastrado!\n",oldValue);
			return lista;
		}
	}
}

int listaVazia(Conta *lista){
	if(lista->prox == NULL){
		return 1;
	}else{
		return 0;
	}
}

void mostrarLista(Conta *lista){
	Conta *aux = lista;
	printf("- - - - - - -\n");
	while(aux != NULL){
		printf("|Nome: %s\n|Saldo: %.2f\n|Num conta: %d\n", aux->titular, aux->saldo, aux->num_conta);
		aux = aux->prox;
		printf("- - - - - - -\n");
	}
}

void liberarLista(Conta *lista){
	Conta *aux;
	aux = lista;
	if(aux != NULL){
		liberarListaRecursao(aux->prox);
		free(aux);
	}
}