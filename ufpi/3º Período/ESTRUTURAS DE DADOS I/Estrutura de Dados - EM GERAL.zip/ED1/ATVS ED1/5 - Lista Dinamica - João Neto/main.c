#include <stdio.h>
#include <stdlib.h>

#include "listadinamicasimples.h"

/*
	as partes comentadas foram os meus teste.
*/

int main(){
	Conta *lista;

	lista = criarLista();

	/* lista = inserirInicio(lista);
	lista = inserirInicio(lista);
	lista = inserirInicio(lista);
	lista = inserirInicio(lista);
	lista = inserirInicio(lista);

	lista = inserirFim(lista);
	lista = inserirFim(lista);
	lista = inserirFim(lista);
	lista = inserirFim(lista);
	lista = inserirFim(lista); */

	/* lista = inserirOrdenado(lista);
	mostrarLista(lista);
	lista = inserirOrdenado(lista);
	mostrarLista(lista);
	lista = inserirOrdenado(lista);
	mostrarLista(lista);
	lista = inserirOrdenado(lista);
	mostrarLista(lista);
	lista = inserirOrdenado(lista);
	mostrarLista(lista);

	mostrarLista(lista);
	printf("\n");

	lista = remover(lista,3);
	mostrarLista(lista);

	printf("\n");
	lista = alterar(lista,1,7);

	mostrarLista(lista);
	liberarLista(lista); */

	return 0;
}