#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"

int main(){

    Pilha *pilha = pilha_cria();

    pilha_inserir(&pilha);
    pilha_inserir(&pilha);
    pilha_inserir(&pilha);
    pilha_inserir(&pilha);
    pilha_inserir(&pilha);

    mostrar_toda_pilha(pilha);

    pilha_remover(&pilha);

    mostrar_toda_pilha(pilha);

    pilha_remover(&pilha);

    mostrar_toda_pilha(pilha);
    
    pilha_libera(&pilha);

    mostrar_toda_pilha(pilha);

    return 0;
}