typedef struct pilha Pilha;
Pilha* pilha_cria(void);
void pilha_inserir(Pilha **p);
void pilha_remover(Pilha **p);
int pilha_vazia(Pilha *p);
void pilha_libera(Pilha **p);
void mostrar_topo_pilha(Pilha *p);
void mostrar_toda_pilha(Pilha *p);