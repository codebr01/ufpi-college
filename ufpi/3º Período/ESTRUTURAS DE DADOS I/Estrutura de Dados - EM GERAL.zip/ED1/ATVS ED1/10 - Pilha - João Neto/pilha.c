#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"

struct pilha{
    int numero;
    float saldo;
    char titular[100];
    Pilha *prox;
};

Pilha *pilha_cria(){
    return NULL;
}

void pilha_inserir(Pilha **p){
    Pilha *new = (Pilha *)malloc(sizeof(Pilha));
    printf("Digite o numero da conta: ");
    scanf("%i", &new->numero);
    printf("Informe o saldo da conta: ");
    scanf("%f", &new->saldo);
    printf("Informe o nome do titular da conta: ");
    scanf("%s", new->titular);

    if(pilha_vazia((*p)) == 0){
        new->prox = NULL;
        (*p) = new;
    }else{
        new->prox = (*p);
        (*p) = new;
    }
}

void pilha_remover(Pilha **p){
    Pilha **aux_p;
    aux_p == p;

    if(pilha_vazia(*p) != 0){
        (*p) = (*p)->prox;
        free(aux_p);
    } 
    
}

int pilha_vazia(Pilha *p){
    if(p != NULL){
        return 1;
    }else{
        return 0;
    }
}

void pilha_libera(Pilha **p){
    Pilha **topo;
    topo = p;
    while((*p) != NULL){
        (*p) = (*p)->prox;
        pilha_remover(topo);
        printf("\nLimpando...\n");
        topo = p;
    }
}

void mostrar_topo_pilha(Pilha *p){
    printf("\nTitular: %s\nNumero: %i\nSaldo: %.2f\n",p->titular,p->numero,p->saldo);
    printf("= = = = = = = = = = =\n");
}

void mostrar_toda_pilha(Pilha *p){
    Pilha *topo = p;
    while(topo != NULL){
        mostrar_topo_pilha(topo);
        topo = topo->prox;
    }
}