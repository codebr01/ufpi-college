#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cabeçalho.h"

struct conta{
    int numero;
    float saldo;
    char titular[100];
    Conta *prox;
};

Conta *create_list(){
    return NULL;
}

Conta *insert(Conta *l){
    Conta *novo = (Conta*)malloc(sizeof(Conta));
    printf("Digite o número da conta: ");
    scanf("%d", &novo->numero);
    setbuf(stdin, NULL);
    printf("Digite o saldo da conta: ");
    scanf("%f", &novo->saldo);
    setbuf(stdin, NULL);
    printf("Digite o nome do titular: ");
    scanf("%s", novo->titular);
    setbuf(stdin, NULL);
    novo->prox = l;
    return novo;
}

void show_all(Conta *l){
    Conta *aux;
    printf("==============\n");
    while(aux != NULL){
        printf("Número da conta: %d\n", aux->numero);
        printf("Saldo da conta: %.2f\n", aux->saldo);
        printf("Nome do titular: %s\n", aux->titular);
        printf("==============\n");
        aux = aux->prox;
    }
}