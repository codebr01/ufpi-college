typedef struct conta Conta;

Conta *create_list();
Conta *insert(Conta *l);
Conta *insert_first(Conta *l);
void show_all(Conta *l);