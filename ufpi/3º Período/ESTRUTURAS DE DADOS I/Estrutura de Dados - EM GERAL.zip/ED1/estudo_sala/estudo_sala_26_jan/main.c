#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cabeçalho.h"

void main(){
    Conta *l = create_list();
    /* l = insert(l);
    l = insert(l);
    l = insert(l); */
    l = insert_first(l);
    l = insert_first(l);
    l = insert_first(l);
    show_all(l);
}