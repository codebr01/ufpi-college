#include <stdlib.h>
#include <stdio.h>
#include "operações.h"

float soma(float x,float y){
    return x+y;
}
float subtrair(float x, float y){
    return x-y;
}
float multiplicar(float x, float y){
    return x*y;
}
float dividir(float x, float y){
    return x/y;
}