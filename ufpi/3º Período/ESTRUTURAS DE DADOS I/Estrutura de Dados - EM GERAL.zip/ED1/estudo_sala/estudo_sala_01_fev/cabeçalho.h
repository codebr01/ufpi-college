typedef struct conta Conta;
typedef struct conta_dupla ContaDupla;

Conta *create_list();
Conta *inserirCircularInicio(Conta *lista);
ContaDupla *inserirDuplaEncadeadaInicio(ContaDupla *lista);
void *imprimeListaCircular(Conta *lista);