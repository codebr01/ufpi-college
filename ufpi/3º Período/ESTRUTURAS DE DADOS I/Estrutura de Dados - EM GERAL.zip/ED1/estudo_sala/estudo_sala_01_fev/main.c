#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cabeçalho.h"

int main(){

    Conta *lista;
    lista = create_list();

    lista = inserirCircular(lista);
    lista = inserirCircular(lista);
    lista = inserirCircular(lista);

    imprimeListaCircular(lista);

    return 0;
}