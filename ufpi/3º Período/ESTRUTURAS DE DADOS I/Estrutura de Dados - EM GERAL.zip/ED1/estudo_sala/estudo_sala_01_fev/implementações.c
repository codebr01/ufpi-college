#include <stdio.h>
#include <stdlib.h>
#include "cabeçalho.h"

struct conta{
	float saldo;
	char titular[100];
	int num_conta;
	struct conta *prox;
};

struct conta_dupla{
    float saldo;
	char titular[100];
	int num_conta;
	struct conta_dupla *prox;
    struct conta_dupla *ant;
};

Conta *create_list(){
    return NULL;
}

ContaDupla *inserirDuplaEncadeadaInicio(ContaDupla *lista){
    ContaDupla *aux;
    aux = lista;
    ContaDupla *new;
    new = (ContaDupla *)malloc(sizeof(ContaDupla));

    printf("Digite o nome da conta: ");
    scanf("%s", new->titular);
    printf("Digite o numero da conta: ");
    scanf("%i", &new->num_conta);
    printf("Digite o saldo da conta: ");
    scanf("%f", &new->saldo);

    new->prox = lista;
    new->ant = NULL;
    if(lista != NULL){
        lista->ant = new;
    }

    return new;

}

Conta *inserirCircularInicio(Conta *lista){
    Conta *aux;
    aux = lista;
    Conta *new;
    new = (Conta *)malloc(sizeof(Conta));
    printf("Digite o nome da conta: ");
    scanf("%s", new->titular);
    printf("Digite o numero da conta: ");
    scanf("%i", &new->num_conta);
    printf("Digite o saldo da conta: ");
    scanf("%f", &new->saldo);

    if(lista == NULL){
        new->prox = new;
        return new;
    }else{
        while(aux->prox != lista){
            aux = aux->prox;
        }
        aux->prox = new;
        new->prox = lista;
        return lista;
    }

}

void *imprimeListaCircular(Conta *lista){
    Conta *aux;
    aux = lista;
    if(aux != NULL){
        do{
            printf("--------------------\n");
            printf("Numero da conta: %i\nSaldo: %.2f\nNome: %s\n", aux->num_conta, aux->saldo, aux->titular);
            printf("--------------------\n");
            aux = aux->prox;
        }while(aux != lista);
    }else{
        printf("Lista Vazia!\n");
    }
}