/*
    ## == Estrutura de Dados I == ##
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int *preencherMatriz(int **matriz, int l, int c);

int *alocaMemoria(int **matriz, int l, int c);

void exibeMatriz(int **matriz, int l, int c);

int *somaMediaMaiorMenor(int **matriz, int l, int c);

void mostraSomaMediaMaiorMenor(int *dados);

int main(){

    int **matriz, *dados;
    srand(time(NULL));
    dados = (int *) calloc(4,sizeof(int));

    matriz = alocaMemoria(matriz,2,2);
    matriz = preencherMatriz(matriz,2,2);
    exibeMatriz(matriz,2,2);
    dados = somaMediaMaiorMenor(matriz,2,2);
    mostraSomaMediaMaiorMenor(dados);

    free(matriz);
    free(dados);

    return 0;
}

void mostraSomaMediaMaiorMenor(int *dados){
    printf("\nSoma: %i\nMenor: %i\nMaior: %i\nMedia: %i\n\n", dados[0], dados[1], dados[2], dados[3]);
}

int *somaMediaMaiorMenor(int **matriz, int l, int c){
    int soma = 0, *dados,maior,menor;
    maior = menor = matriz[0][0];
    dados = (int *) calloc(4,sizeof(int));

    for(int i = 0; i < l; i++){
        for(int j = 0; j < c; j++){
            soma += matriz[i][j];
            if(matriz[i][j] > maior){
                maior = matriz[i][j];
            }
            if(matriz[i][j] < menor){
                menor = matriz[i][j];
            }
        }
    }
    dados[0] = soma;
    dados[1] = menor;
    dados[2] = maior;
    dados[3] = soma / (l * c);

    return dados;
}

int *alocaMemoria(int **matriz, int l, int c){
    matriz = (int **) calloc(l, sizeof(int *));
    for(int i = 0; i < c; i++){
        matriz[i] = (int *) calloc(c, sizeof(int));
    }

    return matriz;
}

int *preencherMatriz(int **matriz, int l, int c){
    for(int i = 0; i < 2; i++){
        for(int j = 0; j < 2; j++){
            matriz[i][j] = rand() % 10;
        }
    }

    return matriz;
}

void exibeMatriz(int **matriz, int l, int c){
    for(int i = 0; i < 2; i++){
        for(int j = 0; j < 2; j++){
            printf("%i ", matriz[i][j]);
        }printf("\n");
    }
}