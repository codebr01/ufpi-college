#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void preencher(int *x, int tam){
    for(int i = 0; i < tam; i++){
        scanf("%i", &x[i]);
    }
}

int main(){
    srand(time(NULL));
    int x = 5, *v, *vet2;

    v = (int *) calloc(x,sizeof(int));
    vet2 = (int *) calloc(x, sizeof(int));
    vet2 = (int *) realloc(v, sizeof(int) * x * 2);

    if((v == NULL)|| (vet2 == NULL)){
        exit(1);
    }
    for (int i = 0; i < x; i++)
    {
        v[i] = rand() % 100;
        printf("%i\n", v[i]);
    }
    for (int i = 0; i < x; i++)
    {
        printf("%i\n", vet2[i]);
    }

    free(v);
    free(vet2);
    
    return 0;
}