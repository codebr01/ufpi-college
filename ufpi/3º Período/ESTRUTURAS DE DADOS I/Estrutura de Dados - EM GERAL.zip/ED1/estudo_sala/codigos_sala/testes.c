#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int **creat_matriz(int linha, int coluna){
	int **mat = (int **)calloc(linha,sizeof(int *));
	for(int i = 0; i < linha; i++){
		mat[i] = (int *)calloc(coluna,sizeof(int));
	}
	return mat;
}

void show_matriz(int **mat, int linha, int coluna){
	for(int i = 0; i < linha; i++){
		for(int j = 0; j < coluna; j++){
			printf("%i ", mat[i][j]);
		}printf("\n");
	}
}

void clear_matriz(int **mat,int linha){
	printf("Endereço da matriz: %p\n", *mat);
	for(int i = 0; i < linha; i++){
		free(mat[i]);
	}
	free(mat);
	mat = NULL;
}

int main(){
	
	int **matriz;
	int linha,coluna;
	linha = coluna = 10;
	matriz = creat_matriz(linha,coluna);
	show_matriz(matriz,linha,coluna);
	printf("Endereço da matriz: %p\n", matriz[0]);
	clear_matriz(matriz,linha);
	if(matriz == NULL){
		printf("Deu certo\n");
	}
	
	return 0;
}