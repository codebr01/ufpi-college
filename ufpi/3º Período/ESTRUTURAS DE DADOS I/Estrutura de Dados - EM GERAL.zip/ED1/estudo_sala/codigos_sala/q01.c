#include <stdio.h>
#include <stdlib.h>

int main(){

    int *v = NULL, num = 0,total = 0, cont = 0, qtd = 0;

    for(;num != -1;){
        scanf("%i", &num);
        setbuf(stdin,NULL);
        if(num == -1){
            break;
        }
        v = (int *) realloc(v,sizeof(int) * (qtd + 1));
        v[cont] = num;
        qtd++;
        cont++;
        total += num;
    }
    free(v);
    printf("Media: %.1f\n", (float)total/cont);
    
    return 0;
}