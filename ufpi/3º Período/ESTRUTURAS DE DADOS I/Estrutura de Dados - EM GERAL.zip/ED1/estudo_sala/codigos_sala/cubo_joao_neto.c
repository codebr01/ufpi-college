#include <stdlib.h>
#include <stdio.h>
#include <math.h>

float distancia(int x1, int x2, int y1, int y2, int z1, int z2){
	int diffX, diffY, diffZ;
	diffX = pow(x2 - x1, 2);
	diffY = pow(y2 - y1, 2);
	diffZ = pow(z2 - z1, 2);
	return sqrt(diffX + diffY + diffZ);
}

int ***preencherCubo(int profundidade, int altura, int largura){

	int ***cubo;

	cubo = (int ***) malloc(profundidade * sizeof(int **));
	for (int i = 0; i < profundidade; ++i)
		cubo[i] = (int **) malloc(sizeof(int *) * altura);

	for (int i = 0; i < profundidade; ++i)
		for (int j = 0; j < altura; ++j)
			cubo[i][j] = (int *) malloc(sizeof(int) * largura);
	
	for (int i = 0; i < profundidade; ++i)
		for (int j = 0; j < altura; ++j)
			for (int x = 0; x < largura; ++x)
			{
				cubo[i][j][x] = 0;
			}
	
	int raio = (int)(largura / 2);
	int xc, yc, zc;
	xc = (int)(largura / 2) + 1;
	yc = (int)(altura / 2) + 1;
	zc = (int)(profundidade / 2) + 1;
	for (int z = 0; z < profundidade; ++z){
		for (int y = 0; y < altura; ++y){
			for (int x = 0; x < largura; ++x)
			{
				if (distancia(x, xc, y, yc, z, zc) <= raio)
				{
					cubo[z][y][x] = 1;
				}

			}
		}
	}	

	return cubo;
}

void mostrarCubo(int largura, int altura, int profundidade, int ***cubo){
	for (int i = 0; i < profundidade; ++i){
		for (int j = 0; j < altura; ++j){
			for (int x = 0; x < largura; ++x)
			{
				printf("%d ", cubo[x][i][j]);
			}
			printf("\n");
		}
		printf("\n");
	}
}


int main()
{
	int ***c, largura = 5, altura = 5, profundidade = 5;
	c = preencherCubo(profundidade, altura, largura);
	mostrarCubo(largura, altura, profundidade, c);
	return 0;
}