#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int **preencherMatriz(int l, int c);

int *maiorMenorMedia(int **matriz, int l, int c);

void mostrarDados(int l, int c, int **matriz);

void mostrarMaiorMenorMedia(int t, int *dados);

int main(){
    srand(time(NULL));

    //Declaração das variáveis
    int l = 4, c = 4, t = 5, p = 5, **matriz, *dados;

    matriz = preencherMatriz(l, c);
    dados = maiorMenorMedia(matriz, l, c);
    mostrarDados(l, c, matriz);
    mostrarMaiorMenorMedia(t, dados);

    for(int i = 0; i < l; i++){
        free(matriz[i]);
    }

    free(matriz);
    free(dados);

    return 0;
}

int **preencherMatriz(int l, int c){
    int **matriz;

    matriz = (int **) calloc(l, sizeof(int *));

    for(int i = 0; i < l; i++){
        matriz[i] = (int *) calloc(c, sizeof(int));
    }

    for(int i = 0; i < l; i++){
        for(int j = 0; j < c; j++){
            matriz[i][j] = rand() % 10;
        }
    }

    return matriz;
}

int *maiorMenorMedia(int **matriz, int l, int c){
    int *dados, maior, menor, soma = 0, media;

    dados = (int *) calloc(3, sizeof(int));

    maior = matriz[0][0];
    menor = matriz[0][0];

    for(int i = 0; i < l; i++){
        for(int j = 0; j < c; j++){
            if(matriz[i][j] >= maior){
                maior = matriz[i][j];
            }

            if (matriz[i][j] <= menor){
                menor = matriz[i][j];
            }

            soma += matriz[i][j];
        }
    }

    dados[0] = maior;
    dados[1] = menor;
    dados[2] = soma / (l * c);

    return dados;
}

void mostrarDados(int l, int c, int **matriz){
    for(int i = 0; i < l; i++){
        for(int j = 0; j < c; j++){
            printf("%4d", matriz[i][j]);
        }
        printf("\n");
    }
}

void mostrarMaiorMenorMedia(int t, int *dados){
    printf("Maior: %d", dados[0]);
    printf("\nMenor: %d", dados[1]);
    printf("\nMedia: %d", dados[2]);
    printf("\n");
}