typedef struct conta Conta;

Conta *criar_pilha();
Conta *inserir_pilha(Conta *pilha);
Conta *remover_pilha(Conta *pilha);
int vazio_pilha(Conta *pilha);
void liberar_pilha(Conta *pilha);
void mostrarTopo_pilha(Conta *pilha);
void mostrarToda_pilha(Conta *pilha);
