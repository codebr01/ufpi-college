#include "cabeçalhoPilha.h"
#include <stdio.h>
#include <stdlib.h>

struct conta{
    int numero;
    float saldo;
    char titular[100];
    Conta *prox;
};

Conta *criar_pilha(){
    return NULL;
}

Conta *inserir_pilha(Conta *pilha){
    Conta *aux = pilha;
    Conta *new = (Conta *)malloc(sizeof(Conta));
    scanf("%s", new->titular);
    new->numero = 1;
    new->saldo = 1000;
        
    if(vazio_pilha(pilha) != 1){
        new->prox = NULL;
        return new;
    }else{
        new->prox = aux;
        return new;
    }
}

Conta *remover_pilha(Conta *pilha){
    Conta *aux = pilha;
    pilha = aux->prox;
    free(aux);
    return pilha;
}

int vazio_pilha(Conta *pilha){
    Conta *aux = pilha;
    if(aux != NULL){
        return 1;
    }else{
        return 0;
    }
}

void liberar_pilha(Conta *pilha){
    Conta *aux = pilha;
    Conta *ant = aux;
    while(aux != NULL){
        aux = aux->prox;
        free(ant);
        ant = aux;
    }
}

void mostrarTopo_pilha(Conta *pilha){
    printf("\nTitular: %s\nNumero: %i\nSaldo: %.2f\n",pilha->titular,pilha->numero,pilha->saldo);
}

void mostrarToda_pilha(Conta *pilha){
    while(pilha != NULL){
        mostrarTopo_pilha(pilha);
        pilha = pilha->prox;
    }
}