#include <stdio.h>
#include <stdlib.h>
#include "cabeçalhoPilha.h"

int main(){
    
    Conta *pilha = criar_pilha();

    pilha = inserir_pilha(pilha);
    pilha = inserir_pilha(pilha);
    pilha = inserir_pilha(pilha);
    pilha = inserir_pilha(pilha);
    mostrarTopo_pilha(pilha);

    pilha = remover_pilha(pilha);

    mostrarTopo_pilha(pilha);

    mostrarToda_pilha(pilha);

    liberar_pilha(pilha);

    return 0;
}