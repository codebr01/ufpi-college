#include <stdio.h>
#include <stdlib.h>
#include "cabecalho.h"

struct _snode{
    int val;
    struct _snode *next;
};

struct _linked_list{
    SNode *begin;
    SNode *end;
};

LinkedList *LinkedList_create(){
    LinkedList *L = (LinkedList *) calloc(1,sizeof(LinkedList));
    L->begin = NULL;
    L->end = NULL;
    return L;
}

SNode *SNode_create(int val){
    SNode *snode = (SNode*) calloc(1,sizeof(SNode));
    snode->val = val;
    snode->next = NULL;
    return snode;
}

bool LinkedList_add_empty(const LinkedList *L){
    return (L->begin == NULL && L->end == NULL);
}

/* void LinkedList_add_first(LinkedList *L, int val){
    SNode *p = SNode_create(val);
    p->next = L->begin;
    L->begin = p;
} */

void LinkedList_add_first(LinkedList *L, int val){
    SNode *p = SNode_create(val);
    p->next = L->begin;
    if(LinkedList_add_empty(L)) L->end = p;
    L->begin = p;
}

void LinkedList_add_last(LinkedList *L, int val){
    SNode *q = SNode_create(val);
    if(LinkedList_add_empty(L)){
        L->begin = q;
        L->end = q;
    }else{
        L->end->next = q;
        L->end = L->end->next;
    }
}

void LinkedList_add_last_slow(LinkedList *L, int val){
    SNode *q = SNode_create(val);
    if(LinkedList_add_empty(L)){
        L->begin = q;
    }else{
        SNode *p = L->begin;
        while(p->next != NULL){
            p = p->next;
        }
        p->next = q;
    }
}

void LinkedList_print(const LinkedList *L){
    SNode *p = L->begin;
    printf("L -> ");
    while(p != NULL){
        printf("%i -> ", p->val);
        p = p->next;
    }
    printf("NULL\n");
}

void LinkedList_remove1(LinkedList *L,int val){
    if(!LinkedList_add_empty(L)){
        if(L->begin->val == val){
            SNode *pos = L->begin;
            L->begin = L->begin->next;
            if(L->begin == L->end){
                L->end = NULL;
            }
            L->begin = L->begin->next;
            free(pos);
        }  
    }else{
        SNode *pos = SNode_create(val);
        SNode *prev = SNode_create(val);
        while(pos != NULL && pos->val != val){
            pos = pos->next;
            prev = prev->next;
        }
        if (pos != NULL){
            prev->next = pos->next;
            if(pos->next == NULL){
                L->end = prev;
            }
            free(pos);
        }
        
    }
}

void LinkedList_remove(LinkedList *L,int val){
    if(!LinkedList_add_empty(L)){
        SNode *pos = SNode_create(val);
        SNode *prev = SNode_create(val);
        while(pos != NULL && pos->val != val){
            prev = pos;
            pos = pos->next;
        }
        if(pos != NULL){
            if(L->end == pos){
                L->end = prev;
            }
            if(L->begin == pos){
                L->begin = pos->next;
            }else{
                prev->next = pos->next;
            }
            free(pos);
        }
    }
}

void LinkedList_destroy(LinkedList **L_ref){
    LinkedList *L = *L_ref;
    SNode *p = L->begin;
    SNode *aux = NULL;

    while(p != NULL){
        aux = p;
        p = p->next;
        free(aux);
    }
    free(L);
    *L_ref = NULL;
}