#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{
	int n, soma = 0;
	scanf("%d", &n);
	int *vetor = (int *) calloc(n, sizeof(int));
	int *vetorr = (int *) calloc(n, sizeof(int));
	int **matriz = (int **) calloc(n, sizeof(int *));
	for(int i = 0; i < n; i++)
	{
		matriz[i] = (int *) calloc(n, sizeof(int));
	}

	for(int i = 0; i < n; i++)
		for(int j = 0; j < n; j++)
			scanf("%d", &matriz[i][j]);
		
	for(int i = 0; i < n; i++)
		scanf("%d", &vetor[i]);

	for(int i = 0; i < n; i++)
	{
		soma = 0;
		for(int j = 0; j < n; j++)
		{
			soma += matriz[i][j] * vetor[j];
		}
		vetorr[i] = soma;
		
	}
	for(int i = 0; i < n; i++)
	{
		printf("%d\n", vetorr[i]);
	}

	for(int i = 0; i < n; i++)
	{
		free(matriz[i]);
	}
	free(matriz);
	free(vetor);
	free(vetorr);
	return 0;
}
