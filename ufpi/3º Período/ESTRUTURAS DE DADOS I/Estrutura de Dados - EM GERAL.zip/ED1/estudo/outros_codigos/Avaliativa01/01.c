#include <stdio.h>
#include <stdlib.h>
#include <math.h>

float pontos(int x1, int y1, int x2, int y2);

int main(int argc, char const *argv[])
{
	int n;
	scanf("%d", &n);
	int **matriz = (int **) calloc(n, sizeof(int *));
	for(int i = 0; i < n; i++)
	{
		matriz[i] = (int *) calloc(n * 5, sizeof(int));
	}


	int centroX = n / 2;
	int centroY = n / 2;
	int raio = n / 2;
	int maxmatriz = n;
	for(int x = 0; x < 5; x++)
	{
		for(int i = 0; i < n; i++)
		{
			for(int j = (n * x); j < maxmatriz; j++)
			{
				if(pontos(i, j, centroX, centroY) < raio)
				{
					matriz[i][j] = 1;
				}
			}
		}
		maxmatriz += n;
		centroY += n;
	}

	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n * 5; j++)
		{
			printf("%d",matriz[i][j]);
		}
		printf("\n");
	}



	for(int i = 0; i < n; i++)
	{
		free(matriz[i]);
	}
	free(matriz);
	return 0;
}


float pontos(int x1, int y1, int x2, int y2)
{
	float result = sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
	return result;
}