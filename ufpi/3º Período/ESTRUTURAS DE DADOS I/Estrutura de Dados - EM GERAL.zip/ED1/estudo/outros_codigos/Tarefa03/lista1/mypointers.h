/* Cabeçalho */

#ifndef MYPOINTERS_H
#define MYPOINTERS_H


int *criar(int n);

void preencher(int n, int *v);

void mostrar(int n, int *v);

void liberar(int *variavel);

float **criarMatriz(int m, int n);

void liberarMatriz(int **variavel);


char *repete(char *s, int n);
char *inverte(char *s);
float *criarTercaoParte(int n);

#endif /* MYPOINTER_H */