#include <stdio.h>
#include <stdlib.h>

int **criar(int m, int n)
{
	int **matriz = (int **) malloc(sizeof(int *) * m);
	for(int i = 0; i < m; i++)
	{
		matriz[i] = (int *) malloc(sizeof(int) * n);
	}
	
	return matriz;
}

void liberar(int m, int n, int **matriz)
{
	for(int i = 0; i < m; i++)
		free(matriz[i]);
	free(matriz);
}

/*
int main(int argc, char const *argv[])
{
	int m, n;
	scanf("%d %d", &m, &n);
	int **matriz = (int **) malloc(sizeof(int *) * m);
	for(int i = 0; i < m; i++)
	{
		matriz[i] = (int *) malloc(sizeof(int) * n);
	}

	return 0;
}

*/

int main(int argc, char const *argv[])
{
	int m, n;
	scanf("%d %d", &m, &n);
	int **matriz = criar(m, n);
	liberar(m, n, matriz);
	return 0;
}

