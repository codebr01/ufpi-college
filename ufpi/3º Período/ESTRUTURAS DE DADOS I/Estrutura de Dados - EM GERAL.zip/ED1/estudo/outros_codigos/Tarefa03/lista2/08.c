#include <stdio.h>
#include <stdlib.h>

int *repete(char *s, char c);

int main(int argc, char const *argv[])
{
	char string[50], c;
	scanf("%s %c", string, &c);

	int *vetor = repete(string, c);
	for(int i = 0; vetor[i] != '\0'; i++)
	{
		printf("%d ", vetor[i]);
	}
	free(vetor);

	return 0;
}

int *repete(char *s, char c)
{
	int *vetor = NULL;
	int count = 0;
	for(int i = 0; s[i] != '\0'; i++)
	{
		if(s[i] == c)
		{
			count++;
			vetor = (int *) realloc(vetor, sizeof(int) * count);
			vetor[count - 1] = i;
		}
	}
	return vetor;
}