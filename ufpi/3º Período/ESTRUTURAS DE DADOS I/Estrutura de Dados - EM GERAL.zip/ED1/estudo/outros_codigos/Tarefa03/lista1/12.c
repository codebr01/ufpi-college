#include <stdio.h>
#include <stdlib.h>

int *manipularVetor(int *v, int tamanho, int menor, int maior);

int main(int argc, char const *argv[])
{
	int tamanho;
	scanf("%d", &tamanho);
	int vetor[tamanho];
	
	for(int i = 0; i < tamanho; i++)
	{
		scanf("%d", &vetor[i]);
	}

	int menor, maior;
	scanf("%d %d", &menor, &maior);
	int *vetorManupulado = manipularVetor(vetor, tamanho, menor, maior);

	for(int i = 0; vetorManupulado[i] != '\0'; i++)
	{
		printf("%d ", vetorManupulado[i]);
	}

	printf("\n");

	return 0;
}


int *manipularVetor(int *v, int tamanho, int menor, int maior)
{
	int *vetor = NULL;
	int count = 1;
	for(int i = 0; i < tamanho; i++)
	{
		if(v[i] > menor && v[i] < maior)
		{
			vetor = (int *) realloc(vetor, sizeof(int) * count);
			vetor[count - 1] = v[i];
			count++;
		}
	}
	return vetor;
}

