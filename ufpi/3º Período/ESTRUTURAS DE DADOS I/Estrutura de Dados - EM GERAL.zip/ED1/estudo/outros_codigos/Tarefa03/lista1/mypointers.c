#include "mypointers.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int *criar(int n)
{
	int *vetor = (int *) calloc(n, sizeof(int));
	return vetor;
}

float **criarMatriz(int m, int n)
{
	float **matriz = (float **) malloc(sizeof(float *) * m);
	for(int i = 0; i < m; i++)
	{
		matriz[i] = (float *) malloc(sizeof(float) * n);
	}
	return matriz;
}

void preencher(int n, int *v)
{
	for(int i = 0; i < n; i++)
	{
		scanf("%d", &v[i]);
	}
}

void mostrar(int n, int *v)
{
	for(int i = 0; i < n; i++)
	{
		printf("%d ", v[i]);
	}
	printf("\n");
}

void liberarMatriz(int **variavel)
{

}

void liberar(int *variavel)
{
	free(variavel);
}


char *repete(char *s, int n)
{
	char *frase = (char *) malloc(sizeof(s) * n + 1);
	printf("%ld", sizeof(frase));
	int aux = 0;
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; s[j] != '\0'; j++, aux++)
		{
			frase[aux] = s[j];
		}
		frase[aux] = ' ';
		aux++;
	}
	frase[aux - 1] = '\0';
	return frase;
}

char *inverte(char *s)
{
	int tam = strlen(s);
	char *inverso = malloc(sizeof(char) * tam);
	
	int j = tam;
	int i;
	for(i = 0; i < tam; i++, j--)
	{
		inverso[i] = s[j - 1];
	}
	inverso[i] = '\0';
	return inverso;
}

float *criarTercaoParte(int n)
{
	float *v = (float *) malloc(sizeof(float) * n);
	for(int i = 0; i < n; i++)
	{
		v[i] = (float) i * (i / 3);
	}
	return v;
}