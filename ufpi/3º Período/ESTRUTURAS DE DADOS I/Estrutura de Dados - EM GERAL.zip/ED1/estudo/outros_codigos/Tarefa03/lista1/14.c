#include <stdio.h>
#include "mypointers.h"

int main(int argc, char const *argv[])
{
    int n;
    scanf("%d", &n);
    int *v = criar(n);
    preencher(n, v);
    mostrar(n, v);
    for(int i = 0; i < n; i++)
    {
        if(v[i] % 2 != 0)
        {
            printf("%d ", v[i]);
        }
    }
    printf("\n");

    return 0;
}
