#include <stdio.h>
#include "mypointers.h"

int main(int argc, char const *argv[])
{
	char t[100];
	scanf("%s", t);
	printf("%s\n", repete(t, 5));
	return 0;
}
