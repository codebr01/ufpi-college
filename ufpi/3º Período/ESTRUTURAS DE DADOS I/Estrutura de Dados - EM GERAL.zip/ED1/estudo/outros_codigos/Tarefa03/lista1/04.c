#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{
    int m, n;
    scanf("%d %d", &m, &n);
    int *vetor = (int *) malloc(sizeof(int) * n * m);
    int **matriz = (int **) malloc(sizeof(int *) * m);

    for(int i = 0; i < m; i++)
    {
        vetor = vetor + (i * n);
        matriz[i] = vetor;
        vetor = vetor - (i * n);
    }

    for(int i = 0; i < m; i++)
    {
        for(int j = 0; j < n; j++)
        {
            scanf("%d", &matriz[i][j]);
        }
    }

    for (int i = 0; i < m; i++)
    {
        for(int j = 0; j < n; j++)
        {
            printf("%d ", matriz[i][j]);
        }
        printf("\n");
    }
    


    return 0;
}
