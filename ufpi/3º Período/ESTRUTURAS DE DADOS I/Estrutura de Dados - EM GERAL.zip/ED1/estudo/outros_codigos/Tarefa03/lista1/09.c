#include <stdio.h>
#include "mypointers.h"

int main(int argc, char const *argv[])
{
	float *p = criarTercaoParte(10);
	for(int i = 0; i < 10; i++)
	{
		printf("%.1f ", p[i]);
	}

	
	return 0;
}
