#include <stdio.h>
#include <stdlib.h>

typedef struct
{
	char nome[50];
	int idade;
	char posicao[50];
	int nume_camisa;
}elenco;

void *criar(int tamanho);
void preencher(elenco *time, int tamanho);
void mostrar(elenco *time, int tamanho);
void limpar(elenco *time);


int main(int argc, char const *argv[])
{
	int tamPrincipal;
	scanf("%d", &tamPrincipal);
	elenco *principal = criar(tamPrincipal);
	preencher(principal, tamPrincipal);
	mostrar(principal, tamPrincipal);
	limpar(principal);


	int tamReserva;
	scanf("%d", &tamReserva);
	elenco *reserva = criar(tamReserva);
	preencher(reserva, tamReserva);
	mostrar(reserva, tamReserva);
	limpar(reserva);
	
	
	return 0;
}

void *criar(int tamanho)
{
	elenco *time = malloc(sizeof(elenco) * tamanho);
	return time;
}

void preencher(elenco *time, int tamanho)
{
	for(int i = 0; i < tamanho; i++)
	{
		scanf("%s", time[i].nome);
		scanf("%d", &time[i].idade);
		scanf("%s", time[i].posicao);
		scanf("%d", &time[i].nume_camisa);
	}
}

void mostrar(elenco *time, int tamanho)
{
	for(int i = 0; i < tamanho; i++)
	{
		printf("Nome: %s\n", time[i].nome);
		printf("Idade: %d\n", time[i].idade);
		printf("Posição: %s\n", time[i].posicao);
		printf("N. Camisa: %d\n", time[i].nume_camisa);
	}
}

void limpar(elenco *time)
{
	free(time);
}