#include <stdio.h>
#include "mypointers.h"

int main(int argc, char const *argv[])
{
    int m, n;
    scanf("%d %d", &m, &n);
    float **matriz = criarMatriz(m, n);

    for(int i = 0; i < m; i++)
    {
        for(int j = 0; j < n; j++)
        {
            scanf("%f", &matriz[i][j]);
        }
    }

    for(int i = 0; i < m; i++)
    {
        for(int j = 0; j < n; j++)
        {
            printf("%.1f ", matriz[i][j]);
        }
        printf("\n");
    }
    return 0;
}
