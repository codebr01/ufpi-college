#include "mypointers.h"
#include <stdio.h>


int main(int argc, char const *argv[])
{
    int n;
    scanf("%d", &n);
    int *v = criar(n);

    for(int i = 0; i < n; i++)
    {
        scanf("%d", &v[i]);
    }
    mostrar(n, v);

    return 0;
}
