#include <stdio.h>
#include <stdlib.h>

int **criarMatriz(int m, int n);
void liberarMatriz(int **matroz, int m);

int main(int argc, char const *argv[])
{
	int m, n;
	scanf("%d %d", &m, &n);

	int **matriz = (int **) malloc(sizeof(int *) * m);
	int *vetor = (int *) malloc(sizeof(int) * (m * n));

	for(int i = 0; i < m; i++)
	{
		vetor = vetor + (i * n);
		matriz[i] = vetor;
		vetor = vetor - (i * n);
	}
	
	return 0;
}

int **criarMatriz(int m, int n)
{
	int **matriz = (int **) malloc(sizeof(int *) * m);
	int *vetor = (int *) malloc(sizeof(int) * (m * n));

	for(int i = 0; i < m; i++)
	{
		vetor = vetor + (i * n);
		matriz[i] = vetor;
		vetor = vetor - (i * n);
	}
	return matriz;
}

void liberarMatriz(int **matroz, int m)
{
	for(int i = 0; i < m; i++)
	{
		free(matroz[i]);
	}
	free(matroz);
}