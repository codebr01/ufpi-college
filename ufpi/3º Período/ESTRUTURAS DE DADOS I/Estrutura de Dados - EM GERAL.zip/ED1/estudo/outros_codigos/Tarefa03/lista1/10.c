#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{
	int n;
	float soma = 0;
	scanf("%d", &n);

	float *vetor = (float *) malloc(sizeof(float) * n);

	for(int i = 0; i < n; i++)
	{
		scanf("%f", &vetor[i]);
		soma += vetor[i];
	}
	
	printf("media: %.1f\n", soma / n);
	free(vetor);
	return 0;
}
