#include <stdio.h>
#include "mypointers2.h"

int main(int argc, char const *argv[])
{
	int n;
	scanf("%d", &n);
	int *vetor = criar(n);
	preencher(n, vetor);
	mostrar(n, vetor);
	liberar(vetor);
	return 0;
}
