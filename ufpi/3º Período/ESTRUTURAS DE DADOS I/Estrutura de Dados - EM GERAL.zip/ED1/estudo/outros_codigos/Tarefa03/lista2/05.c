#include <stdio.h>
#include <stdlib.h>
#include "mypointers2.h"

int main(int argc, char const *argv[])
{
	int n1;
	scanf("%d", &n1);
	int *v1 = criar(n1);
	preencher(n1, v1);

	int n2;
	scanf("%d", &n2);
	int *v2 = criar(n2);
	preencher(n2, v2);

	int **matriz = multiplicacaoVetor(v1, v2, n1, n2);

	for(int i = 0; i < n1; i++)
	{
		for(int j = 0; j < n2; j++)
		{
			printf("%d ", matriz[i][j]);
		}
		printf("\n");
	}

	for(int i = 0; i < n2; i++)
	{
		free(matriz[i]);
	}
	free(matriz);
	liberar(v1);
	liberar(v2);
	
	return 0;
}
