#include "mypointers.h"
#include <stdio.h>


int main(int argc, char const *argv[])
{
	int n;
	scanf("%d", &n);
	int *v = criar(n);
	preencher(n, v);

	for(int i = 0; i < n; i++)
	{
		printf("%d ", v[i]);
	}
	printf("\n");
	liberar(v);
	return 0;
}
