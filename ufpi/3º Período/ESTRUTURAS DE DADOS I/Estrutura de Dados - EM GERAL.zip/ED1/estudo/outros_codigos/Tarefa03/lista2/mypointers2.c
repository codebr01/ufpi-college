#include "mypointers2.h"
#include <stdio.h>
#include <stdlib.h>

int *criar(int n)
{
	int *iPtr = (int *) malloc(sizeof(int) * n);
	return iPtr;
}

void preencher(int n, int *v)
{
	for(int i = 0; i < n; i++)
	{
		scanf("%d", &v[i]);
	}
}

void mostrar(int n, int *v)
{
	for(int i = 0; i < n; i++)
	{
		printf("%d ", v[i]);
	}
	printf("\n");
}

void liberar(int *variavel)
{
	free(variavel);
}

int *concatenarInteiro(int *v1, int *v2, int q1, int q2)
{
	int *vConcatenado = malloc(sizeof(int) * (q1 + q2));
	for(int i = 0; i < q1; i++)
	{
		vConcatenado[i] = v1[i];
	}

	for(int i = q1; i < (q1 + q2); i++)
	{
		vConcatenado[i] = v2[i - q1];
	}
	return vConcatenado;
}

int **multiplicacaoVetor(int *v1, int *v2, int q1, int q2)
{
	int **matriz = (int **) calloc(q1, sizeof(int *));
	for(int i = 0; i < q1; i++)
		matriz[i] = (int *) calloc(q2, sizeof(int));
	
	for(int i = 0; i < q1; i++)
	{
		for(int j = 0; j < q2; j++)
		{
			matriz[i][j] = v1[i] * v2[j];
		}
	}

	return matriz;
}