/* Cabeçalho */

#ifndef MYPOINTERS_H
#define MYPOINTERS_H


int *criar(int n);

void preencher(int n, int *v);

void mostrar(int n, int *v);

void liberar(int *variavel);

int *concatenarInteiro(int *v1, int *v2, int q1, int q2);

int **multiplicacaoVetor(int *v1, int *v2, int q1, int q2);

#endif /* MYPOINTER_H */