#include <stdio.h>
#include <stdlib.h>

int *concatenar(int *v1, int *v2, int tam1, int tam2);

int main(int argc, char const *argv[])
{
	int tam1;
	scanf("%d", &tam1);
	int v1[tam1];
	for(int i = 0; i < tam1; i++)
		scanf("%d", &v1[i]);
	
	int tam2;
	scanf("%d", &tam2);
	int v2[tam2];
	for(int i = 0; i < tam2; i++)
		scanf("%d", &v2[i]);
	
	int *v3 = concatenar(v1, v2, tam1, tam2);

	for(int i = 0; v3[i] != '\0'; i++)
	{
		printf("%d ", v3[i]);
	}
	printf("\n");
	
	return 0;
}

int *concatenar(int *v1, int *v2, int tam1, int tam2)
{
	int *iPtr = (int *) malloc(sizeof(int) * (tam1 + tam2));
	for(int i = 0; i < tam1; i++)
	{
		iPtr[i] = v1[i];
	}

	for(int i = tam1; i < (tam1 + tam2); i++)
	{
		iPtr[i] = v2[i - tam1];
	}

	return iPtr;
}