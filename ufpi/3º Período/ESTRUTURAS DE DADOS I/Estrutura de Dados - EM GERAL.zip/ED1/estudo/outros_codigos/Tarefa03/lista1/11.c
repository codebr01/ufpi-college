#include <stdio.h>
#include <stdlib.h>

double **cria(int m, int n);
void preencher(double **matriz, int m, int n);
double **soma(double **matriz1, double **matriz2, int m, int n);

int main(int argc, char const *argv[])
{
	int m, n;
	scanf("%d %d", &m, &n);

	double **m1 = cria(m, n);
	double **m2 = cria(m, n);
	double **sum = soma(m1, m2, m, n);

	for(int i = 0; i < m; i++)
	{
		for(int j = 0; j < n; j++)
		{
			printf("%.1lf ", sum[i][j]);
		}
		printf("\n");
	}
	return 0;
}


double **cria(int m, int n)
{
	double **matriz = (double **) malloc(sizeof(double *) * m);
	for(int i = 0; i < m; i++)
	{
		matriz[i] = (double *) malloc(sizeof(double) * n);
	}
	preencher(matriz, m, n);
	return matriz;
}

void preencher(double **matriz, int m, int n)
{
	for(int i = 0; i < m; i++)
	{
		for(int j = 0; j < n; j++)
		{
			matriz[i][j] = (double)(rand()% 10);
		}
	}
}

double **soma(double **matriz1, double **matriz2, int m, int n)
{
	double **soma = cria(m, n);
	for(int i = 0; i < m; i++)
	{
		for(int j = 0; j < n; j++)
		{
			soma[i][j] = matriz1[i][j] + matriz2[i][j];
		}
	}
	return soma;
}