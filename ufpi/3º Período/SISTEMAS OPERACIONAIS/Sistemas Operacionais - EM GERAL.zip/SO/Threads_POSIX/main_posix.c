#include <pthread.h>
#include <stdio.h>

void *sum_pares(void *sum_par_pointer){

	int *sum_par = (int *)sum_par_pointer;

	for(int i = 0; i <= 10; i++){
        if(i % 2 == 0){
            *sum_par += i;
        }
    }

	printf("Thread soma_pares terminou a soma de números pares: %i\n", *sum_par);

	return NULL;

}

void *sum_impares(void *sum_impar_pointer){

	int *sum_impar = (int *)sum_impar_pointer;

	for(int i = 0; i <= 10; i++){
        if(i % 2 != 0){
            *sum_impar += i;
        }
    }

	printf("Thread soma_impares terminou a soma de números pares: %i\n", *sum_impar);

	return NULL;

}


int main(){

    int sum_par = 0, sum_impar = 0;

    pthread_t th_sum_par;
    pthread_t th_sum_impar;

    pthread_create(&th_sum_par, NULL, sum_pares, &sum_par);
    pthread_create(&th_sum_impar, NULL, sum_impares, &sum_impar);
    
    pthread_join(th_sum_par,NULL);
    pthread_join(th_sum_impar,NULL);

    printf("Soma pares [ %i ] + Soma Impares [ %i ] = %i\n", sum_par,sum_impar, sum_par+sum_impar);

    return 0;
}