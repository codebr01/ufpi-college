//FUNÇÃO DE SOMAR TODOS OS PARES DE 0 A 10
void *sum_pares(void *sum_par_pointer);
//FUNÇÃO DE SOMAR TODOS OS IMPARES DE 0 A 10
void *sum_impares(void *sum_impar_pointer);