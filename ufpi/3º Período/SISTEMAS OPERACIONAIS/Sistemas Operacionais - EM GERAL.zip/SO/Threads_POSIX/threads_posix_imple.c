#include <pthread.h>
#include <stdio.h>
#include "threads_posix.h"

void *sum_pares(void *sum_par_pointer){

	int *sum_par = (int *)sum_par_pointer;

	for(int i = 0; i <= 10; i++){
        if(i % 2 == 0){
            *sum_par += i;
        }
    }

	printf("Thread soma_pares terminou a soma de números pares: %i\n", *sum_par);

	return NULL;

}

void *sum_impares(void *sum_impar_pointer){

	int *sum_impar = (int *)sum_impar_pointer;

	for(int i = 0; i <= 10; i++){
        if(i % 2 != 0){
            *sum_impar += i;
        }
    }

	printf("Thread soma_impares terminou a soma de números pares: %i\n", *sum_impar);

	return NULL;

}